import React from "react"
import Footer from "../../Components/Footer/Footer"
import Header from "../../Components/Header/Header"
import Navbar from "../../Components/Navbar/Navbar"

export default () => {
  return (
    <>
      <Navbar></Navbar>
      <Header></Header>
      <Footer></Footer>
    </>
  );
}