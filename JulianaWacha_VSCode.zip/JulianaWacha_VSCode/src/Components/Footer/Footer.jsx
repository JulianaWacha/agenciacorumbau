import React from "react"
import './Footer.css'

export default () => {
    return (
        <footer className="footer">
            <p>
                &copy;  2021 Juliana Wacha - Todos os direitos reservados.
            </p>
        </footer>
    );
}

